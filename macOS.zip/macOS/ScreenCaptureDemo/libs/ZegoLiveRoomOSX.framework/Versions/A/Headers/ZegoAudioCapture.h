//
//  ZegoAudioCapture.h
//  ZegoLiveRoom
//
//  Copyright © 2017年 zego. All rights reserved.
//

#ifndef ZegoAudioCapture_h
#define ZegoAudioCapture_h

#include "audio_in_output.h"

#endif /* ZegoAudioCapture_h */
