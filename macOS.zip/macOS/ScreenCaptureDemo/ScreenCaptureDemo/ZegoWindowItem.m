//
//  ZegoWindowItem.m
//  ScreenCaptureDemo
//
//  Created by 李展鹏 on 2018/4/1.
//  Copyright © 2018年 Zego. All rights reserved.
//

#import "ZegoWindowItem.h"

@implementation ZegoWindowItem

@end
