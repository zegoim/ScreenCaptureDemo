//
//  AppDelegate.m
//  ScreenCaptureDemo
//
//  Created by 李展鹏 on 2018/3/31.
//  Copyright © 2019年 Zego. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    

}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
