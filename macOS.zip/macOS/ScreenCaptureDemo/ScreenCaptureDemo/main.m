//
//  main.m
//  ScreenCaptureDemo
//
//  Created by 李展鹏 on 2018/3/31.
//  Copyright © 2018年 李展鹏. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
