//
//  AppDelegate.h
//  ScreenCaptureDemo
//
//  Created by 李展鹏 on 2018/3/31.
//  Copyright © 2018年 Zego. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface AppDelegate : NSObject <NSApplicationDelegate>

@end

