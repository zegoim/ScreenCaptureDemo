//
//  ZegoScreenItem.m
//  ScreenCaptureDemo
//
//  Created by 李展鹏 on 2018/4/1.
//  Copyright © 2019年 Zego. All rights reserved.
//

#import "ZegoScreenItem.h"

@implementation ZegoScreenItem

@end
