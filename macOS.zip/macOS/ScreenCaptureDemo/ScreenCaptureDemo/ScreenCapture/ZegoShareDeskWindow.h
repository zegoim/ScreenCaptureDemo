//
//  ZegoShareDeskWindow.h
//  ScreenCaptureDemo
//
//  Created by MrLQ  on 2019/7/23.
//  Copyright © 2019年 Zego. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZegoShareDeskWindow : NSWindowController

@end

@interface ZegoLayerWindow : NSWindow


@end


NS_ASSUME_NONNULL_END
